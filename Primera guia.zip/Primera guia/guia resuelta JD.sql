-- ============================================================
--  PRÁCTICA 5 - BDY1102 BASE DE DATOS APLICADA II
--  Clínica KETEKURA - Subconsultas para Visualizar Información
--  Usuario: BDY1102_P5
-- ============================================================


/* ============================================================
   CASO 1 - PARTE 1
   Beneficio Fonasa e Isapres
   Entidades de salud con total de atenciones en el mes anterior
   MAYOR al promedio diario de atenciones de ese mismo mes.
   - Filtro: solo tipos 'F' (Fonasa) e 'I' (Isapre)
   - La fecha se obtiene automáticamente (mes anterior a SYSDATE)
   - Ordenado: tipo_sal_id, descripcion (alfabético)
   ============================================================ */

SELECT ts.tipo_sal_id                   AS "TIPO SALUD",
       ts.descripcion                   AS "DESCRIPCION",
       COUNT(a.ate_id)                  AS "TOTAL ATENCIONES"
FROM   ATENCION     a
JOIN   PACIENTE     p  ON a.pac_run      = p.pac_run
JOIN   SALUD        s  ON p.sal_id       = s.sal_id
JOIN   TIPO_SALUD   ts ON s.tipo_sal_id  = ts.tipo_sal_id
WHERE  ts.tipo_sal_id IN ('F', 'I')
  AND  TRUNC(a.fecha_atencion, 'MM') = TRUNC(ADD_MONTHS(SYSDATE, -1), 'MM')
GROUP  BY ts.tipo_sal_id, ts.descripcion
HAVING COUNT(a.ate_id) > (
           -- Promedio diario = total atenciones del mes / días del mes
           SELECT COUNT(*) /
                  TO_NUMBER(TO_CHAR(LAST_DAY(ADD_MONTHS(SYSDATE, -1)), 'DD'))
           FROM   ATENCION
           WHERE  TRUNC(fecha_atencion, 'MM') = TRUNC(ADD_MONTHS(SYSDATE, -1), 'MM')
       )
ORDER  BY ts.tipo_sal_id, ts.descripcion;


/* ============================================================
   CASO 1 - PARTE 2
   Beneficio tercera edad
   Pacientes con 65+ años (edad calculada con fecha completa)
   que tuvieron más de 4 atenciones en el año actual.
   Descuento según tabla PORC_DESCTO_3RA_EDAD.
   Nota: 64 años + 6 o más meses → se redondea a 65 (ROUND).
   ============================================================ */

SELECT p.pac_run || '-' || p.dv_run                                              AS "RUN PACIENTE",
       p.apaterno || ' ' || p.amaterno || ' ' ||
       p.pnombre  || ' ' || p.snombre                                            AS "NOMBRE COMPLETO",
       ROUND(MONTHS_BETWEEN(SYSDATE, p.fecha_nacimiento) / 12)                   AS "EDAD",
       pd.porcentaje_descto || '% 1ERA CONSULTA AÑO ' ||
           TO_CHAR(EXTRACT(YEAR FROM SYSDATE) + 1)                               AS "PORCENTAJE DESCUENTO"
FROM   PACIENTE           p
JOIN   PORC_DESCTO_3RA_EDAD pd
    ON ROUND(MONTHS_BETWEEN(SYSDATE, p.fecha_nacimiento) / 12)
       BETWEEN pd.anno_ini AND pd.anno_ter
WHERE  ROUND(MONTHS_BETWEEN(SYSDATE, p.fecha_nacimiento) / 12) >= 65
  AND  (SELECT COUNT(*)
        FROM   ATENCION a
        WHERE  a.pac_run = p.pac_run
          AND  EXTRACT(YEAR FROM a.fecha_atencion) = EXTRACT(YEAR FROM SYSDATE)
       ) > 4
ORDER  BY p.apaterno;


/* ============================================================
   CASO 2
   Médicos con especialidades que tuvieron menos de 10
   atenciones médicas durante el año anterior.
   Incluye especialidades con 0 atenciones en el año.
   Ordenado: nombre especialidad, apellido paterno médico.
   ============================================================ */

SELECT e.nombre                                          AS "ESPECIALIDAD",
       m.apaterno || ' ' || m.amaterno || ' ' ||
       m.pnombre  || ' ' || m.snombre                   AS "NOMBRE MEDICO"
FROM   MEDICO             m
JOIN   ESPECIALIDAD_MEDICO em ON m.med_run = em.med_run
JOIN   ESPECIALIDAD        e  ON em.esp_id = e.esp_id
WHERE  em.esp_id IN (
           -- Especialidades con al menos 1 atención pero < 10 en el año anterior
           SELECT esp_id
           FROM   ATENCION
           WHERE  EXTRACT(YEAR FROM fecha_atencion) = EXTRACT(YEAR FROM SYSDATE) - 1
           GROUP  BY esp_id
           HAVING COUNT(*) < 10
           UNION
           -- Especialidades sin ninguna atención registrada en el año anterior
           SELECT esp_id
           FROM   ESPECIALIDAD
           WHERE  esp_id NOT IN (
                      SELECT DISTINCT esp_id
                      FROM   ATENCION
                      WHERE  EXTRACT(YEAR FROM fecha_atencion) = EXTRACT(YEAR FROM SYSDATE) - 1
                  )
       )
ORDER  BY e.nombre, m.apaterno;


/* ============================================================
   CASO 3
   Médicos que realizaron MENOS del máximo de atenciones
   registradas por cualquier médico durante el año anterior.
   Los resultados quedan almacenados en MEDICOS_SERVICIO_COMUNIDAD.

   Correo institucional:
     [2 primeras letras unidad]
     + [penúltima y antepenúltima letra de apellido paterno]
     + [3 últimos dígitos del teléfono]
     + [día y mes de contratación (DDMM)]
     + @medicocktk.cl
   (todo en minúsculas)
   ============================================================ */

-- Paso 1: Crear la tabla destino (ejecutar solo la primera vez)
CREATE TABLE MEDICOS_SERVICIO_COMUNIDAD (
    unidad                VARCHAR2(40),
    nombre_completo       VARCHAR2(70),
    telefono              NUMBER(11),
    correo_institucional  VARCHAR2(100),
    total_atenciones      NUMBER(5)
);

-- Paso 2: Insertar los datos en la tabla
INSERT INTO MEDICOS_SERVICIO_COMUNIDAD
           (unidad, nombre_completo, telefono, correo_institucional, total_atenciones)
SELECT u.nombre,
       m.apaterno || ' ' || m.amaterno || ' ' ||
       m.pnombre  || ' ' || m.snombre,
       m.telefono,
       -- Construcción del correo institucional (todo en minúsculas)
       LOWER(
           SUBSTR(u.nombre, 1, 2)                                   -- 2 primeras letras de la unidad
           || SUBSTR(m.apaterno, LENGTH(m.apaterno) - 1, 1)         -- penúltima letra apaterno
           || SUBSTR(m.apaterno, LENGTH(m.apaterno) - 2, 1)         -- antepenúltima letra apaterno
           || SUBSTR(TO_CHAR(m.telefono), -3)                       -- 3 últimos dígitos teléfono
           || TO_CHAR(m.fecha_contrato, 'DDMM')                     -- día y mes del contrato
           || '@medicocktk.cl'
       ),
       COUNT(a.ate_id)
FROM   MEDICO  m
JOIN   UNIDAD  u ON m.uni_id = u.uni_id
LEFT JOIN ATENCION a
    ON  m.med_run = a.med_run
    AND EXTRACT(YEAR FROM a.fecha_atencion) = EXTRACT(YEAR FROM SYSDATE) - 1
GROUP  BY u.nombre,
          m.apaterno, m.amaterno, m.pnombre, m.snombre,
          m.telefono, m.fecha_contrato, m.med_run
HAVING COUNT(a.ate_id) < (
           SELECT MAX(cnt)
           FROM (
               SELECT COUNT(*) AS cnt
               FROM   ATENCION
               WHERE  EXTRACT(YEAR FROM fecha_atencion) = EXTRACT(YEAR FROM SYSDATE) - 1
               GROUP  BY med_run
           )
       );

COMMIT;

-- Paso 3: Visualizar el resultado
SELECT unidad                AS "UNIDAD",
       nombre_completo       AS "NOMBRE COMPLETO MEDICO",
       telefono              AS "TELEFONO",
       correo_institucional  AS "CORREO INSTITUCIONAL",
       total_atenciones      AS "TOTAL ATENCIONES"
FROM   MEDICOS_SERVICIO_COMUNIDAD
ORDER  BY unidad, nombre_completo;


/* ============================================================
   CASO 4 - INFORME 1
   Meses con atenciones IGUAL O MAYOR al promedio mensual
   durante los últimos 3 años (año actual y los 2 anteriores).
   ============================================================ */

SELECT TO_CHAR(TRUNC(fecha_atencion, 'MM'), 'MM/YYYY')  AS "AÑO Y MES",
       COUNT(*)                                          AS "TOTAL ATENCIONES",
       SUM(costo)                                        AS "MONTO TOTAL ATENCIONES"
FROM   ATENCION
WHERE  EXTRACT(YEAR FROM fecha_atencion)
           BETWEEN EXTRACT(YEAR FROM SYSDATE) - 2
               AND EXTRACT(YEAR FROM SYSDATE)
GROUP  BY TRUNC(fecha_atencion, 'MM')
HAVING COUNT(*) >= (
           -- Promedio mensual de atenciones en el período de 3 años
           SELECT AVG(cnt)
           FROM (
               SELECT COUNT(*) AS cnt
               FROM   ATENCION
               WHERE  EXTRACT(YEAR FROM fecha_atencion)
                          BETWEEN EXTRACT(YEAR FROM SYSDATE) - 2
                              AND EXTRACT(YEAR FROM SYSDATE)
               GROUP  BY TRUNC(fecha_atencion, 'MM')
           )
       )
ORDER  BY TRUNC(fecha_atencion, 'MM');


/* ============================================================
   CASO 4 - INFORME 2
   Pacientes con días de morosidad MAYOR al promedio anual
   de morosidad en los últimos 3 años.
   Multa = días de morosidad x $2.000.
   Ordenado: fecha_venc_pago ASC, días morosidad DESC.
   ============================================================ */

SELECT p.pac_run || '-' || p.dv_run                              AS "RUN",
       p.apaterno || ' ' || p.amaterno || ' ' ||
       p.pnombre  || ' ' || p.snombre                           AS "NOMBRE COMPLETO",
       a.ate_id                                                  AS "ID ATENCION",
       TO_CHAR(pa.fecha_venc_pago, 'DD/MM/YYYY')                AS "FECHA VENCIMIENTO PAGO",
       TO_CHAR(pa.fecha_pago,      'DD/MM/YYYY')                AS "FECHA PAGO",
       (pa.fecha_pago - pa.fecha_venc_pago)                     AS "DIAS MOROSIDAD",
       (pa.fecha_pago - pa.fecha_venc_pago) * 2000              AS "VALOR MULTA"
FROM   PAGO_ATENCION  pa
JOIN   ATENCION        a ON pa.ate_id  = a.ate_id
JOIN   PACIENTE        p ON a.pac_run  = p.pac_run
WHERE  pa.fecha_pago > pa.fecha_venc_pago
  AND  EXTRACT(YEAR FROM pa.fecha_venc_pago)
           BETWEEN EXTRACT(YEAR FROM SYSDATE) - 2
               AND EXTRACT(YEAR FROM SYSDATE)
  AND  (pa.fecha_pago - pa.fecha_venc_pago) > (
           -- Promedio de días de morosidad en los 3 años
           SELECT AVG(fecha_pago - fecha_venc_pago)
           FROM   PAGO_ATENCION
           WHERE  fecha_pago > fecha_venc_pago
             AND  EXTRACT(YEAR FROM fecha_venc_pago)
                      BETWEEN EXTRACT(YEAR FROM SYSDATE) - 2
                          AND EXTRACT(YEAR FROM SYSDATE)
       )
ORDER  BY pa.fecha_venc_pago ASC,
          (pa.fecha_pago - pa.fecha_venc_pago) DESC;


/* ============================================================
   CASO 5
   Bono para médicos con más de 7 atenciones en el año.
   Bono por médico = 5% de ganancias / total médicos calificados.

   VARIABLES DE SUSTITUCIÓN (SQL Developer solicitará el valor):
     &ganancias → monto de ganancias acumuladas del año
                  (primera prueba: 2250000000)

   El año se obtiene automáticamente de SYSDATE.
   Ordenado: med_run ASC, apaterno ASC.
   ============================================================ */

SELECT m.med_run || '-' || m.dv_run                              AS "RUN",
       m.apaterno || ' ' || m.amaterno || ' ' ||
       m.pnombre  || ' ' || m.snombre                           AS "NOMBRE COMPLETO",
       COUNT(a.ate_id)                                           AS "TOTAL ATENCIONES",
       TO_CHAR(
           ROUND(
               (&ganancias * 0.05) / (
                   -- Total de médicos que califican para el bono
                   SELECT COUNT(*)
                   FROM (
                       SELECT med_run
                       FROM   ATENCION
                       WHERE  EXTRACT(YEAR FROM fecha_atencion) = EXTRACT(YEAR FROM SYSDATE)
                       GROUP  BY med_run
                       HAVING COUNT(*) > 7
                   )
               )
           ),
           'FM$999,999,999,999'
       )                                                         AS "BONO"
FROM   MEDICO   m
JOIN   ATENCION a ON m.med_run = a.med_run
WHERE  EXTRACT(YEAR FROM a.fecha_atencion) = EXTRACT(YEAR FROM SYSDATE)
GROUP  BY m.med_run, m.dv_run,
          m.apaterno, m.amaterno, m.pnombre, m.snombre
HAVING COUNT(a.ate_id) > 7
ORDER  BY m.med_run, m.apaterno;
